<?php include ('./conn/conn.php') ?>

<!-- Add Book Modal -->
<div class="modal fade mt-5" id="addBookModal" tabindex="-1" aria-labelledby="addBook" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addBook">Add Book</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="./endpoint/add-book.php" method="POST">
                <div class="form-group">
                    <label for="bookTitle">Book Title</label>
                    <input type="text" class="form-control" id="bookTitle" name="book_title">
                </div>
                <div class="form-group">
                    <label for="bookAuthor">Book Author</label>
                    <input type="text" class="form-control" id="bookAuthor" name="book_author">
                </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-dark">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Update Book Modal -->
<div class="modal fade mt-5" id="updateBookModal" tabindex="-1" aria-labelledby="updateBook" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="updateBook">Update Book</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="./endpoint/update-book.php" method="POST">
                    <input type="text" class="form-control" id="updateBookID" name="tbl_book_list_id" hidden>
                <div class="form-group">
                    <label for="updateBookTitle">Book Title</label>
                    <input type="text" class="form-control" id="updateBookTitle" name="book_title">
                </div>
                <div class="form-group">
                    <label for="updateBookAuthor">Book Author</label>
                    <input type="text" class="form-control" id="updateBookAuthor" name="book_author">
                </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-dark">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Add Borrowed Book Modal -->
<div class="modal fade mt-5" id="addBorrowedBookModal" tabindex="-1" aria-labelledby="addBorrowedBook" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addBorrowedBook">Add Borrowed Book</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="./endpoint/add-borrowed-book.php" method="POST">
                    <div class="form-group">
                        <label for="borrowedBook">Book</label>
                        <select class="form-control" name="tbl_book_list_id" id="borrowedBook">
                            <option value="">-select-</option>

                            <?php 
                                include("../conn/conn.php");

                                $stmt = $conn->prepare("SELECT * FROM tbl_book_list");
                                $stmt->execute();

                                $result = $stmt->fetchAll();

                                foreach ($result as $row) {
                                    $bookID = $row['tbl_book_list_id'];
                                    $bookTitle = $row['book_title'];
                                    $bookAuthor = $row['book_author'];
                                    ?>
                                    <option value="<?= $bookID ?>"><?= $bookTitle ?> by <?= $bookAuthor ?></option>
                                    <?php
                                }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="borrowerName">Borrower's Name</label>
                        <input type="text" class="form-control" id="borrowerName" name="borrower_name">
                    </div>
                    <div class="form-group">
                        <label for="borrowerContact">Borrower's Contact</label>
                        <input type="number" class="form-control" id="borrowerContact" name="borrower_contact" maxlength="11">
                    </div>
                    <div class="form-group">
                        <label for="dateBorrowed">Date Borrowed</label>
                        <input type="datetime-local" class="form-control" id="dateBorrowed" name="date_borrowed">
                    </div>
                    <div class="form-group">
                        <label for="dateReturn">Return On</label>
                        <input type="datetime-local" class="form-control" id="dateReturn" name="date_return">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-dark">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Update Borrowed Book Modal -->
<div class="modal fade mt-5" id="updateBorrowedBookModal" tabindex="-1" aria-labelledby="updateBorrowedBook" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="updateBorrowedBook">Update Borrowed Book</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="./endpoint/update-borrowed-book.php" method="POST">
                    <input type="text" class="form-control" id="updateBorrowedID" name="tbl_borrowed_book_id" hidden>
                    <div class="form-group">
                        <label for="updateBorrowedBook">Book</label>
                        <select class="form-control" name="tbl_book_list_id" id="updateBorrowedBook">
                            <option value="">-select-</option>

                            <?php 
                                include("../conn/conn.php");

                                $stmt = $conn->prepare("SELECT * FROM tbl_book_list");
                                $stmt->execute();

                                $result = $stmt->fetchAll();

                                foreach ($result as $row) {
                                    $bookID = $row['tbl_book_list_id'];
                                    $bookTitle = $row['book_title'];
                                    $bookAuthor = $row['book_author'];
                                    ?>
                                    <option value="<?= $bookID ?>"><?= $bookTitle ?> by <?= $bookAuthor ?></option>
                                    <?php
                                }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="updateBorrowerName">Borrower's Name</label>
                        <input type="text" class="form-control" id="updateBorrowerName" name="borrower_name">
                    </div>
                    <div class="form-group">
                        <label for="updateBorrowerContact">Borrower's Contact</label>
                        <input type="number" class="form-control" id="updateBorrowerContact" name="borrower_contact" maxlength="11">
                    </div>
                    <div class="form-group">
                        <label for="updateDateBorrowed">Date Borrowed</label>
                        <input type="datetime-local" class="form-control" id="updateDateBorrowed" name="date_borrowed">
                    </div>
                    <div class="form-group">
                        <label for="updateDateReturn">Return On</label>
                        <input type="datetime-local" class="form-control" id="updateDateReturn" name="date_return">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-dark">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>