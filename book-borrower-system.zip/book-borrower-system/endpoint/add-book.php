<?php
include("../conn/conn.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['book_title'], $_POST['book_author'])) {
        $bookTitle = $_POST['book_title'];
        $bookAuthor = $_POST['book_author'];
        $dateAdded = date("Y-m-d H:i:s");

        try {
            $stmt = $conn->prepare("INSERT INTO tbl_book_list (book_title, book_author, date_added) VALUES (:book_title, :book_author, :date_added)");
            
            $stmt->bindParam("book_title", $bookTitle, PDO::PARAM_STR);
            $stmt->bindParam("book_author", $bookAuthor, PDO::PARAM_STR);
            $stmt->bindParam("date_added", $dateAdded, PDO::PARAM_STR);

            $stmt->execute();

            echo "
                <script>
                    alert('Book Added Successfully!');
                    window.location.href = 'http://localhost/book-borrower-system/book-list.php';
                </script>
            ";
        } catch (PDOException $e) {
            echo "Error:". $e->getMessage();
         }

    } else {
        echo "
            <script>
                alert('Please fill in both title and author fields!');
                window.location.href = 'http://localhost/book-borrower-system/book-list.php';
            </script>
        ";
    }
}

?>