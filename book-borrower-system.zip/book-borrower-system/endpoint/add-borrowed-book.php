<?php
include("../conn/conn.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['tbl_book_list_id'], $_POST['borrower_name'], $_POST['borrower_contact'], $_POST['date_borrowed'], $_POST['date_return'])) {
        $bookID = $_POST['tbl_book_list_id'];
        $borrowerName = $_POST['borrower_name'];
        $borrowerContact = $_POST['borrower_contact'];
        $dateBorrowed = $_POST['date_borrowed'];
        $dateReturn = $_POST['date_return'];

        try {
            $stmt = $conn->prepare("INSERT INTO tbl_borrowed_book (tbl_book_list_id, borrower_name, borrower_contact, date_borrowed, date_return) VALUES (:tbl_book_list_id, :borrower_name, :borrower_contact, :date_borrowed, :date_return)");

            $stmt->bindParam(":tbl_book_list_id", $bookID, PDO::PARAM_INT);
            $stmt->bindParam(":borrower_name", $borrowerName, PDO::PARAM_STR);
            $stmt->bindParam(":borrower_contact", $borrowerContact, PDO::PARAM_STR);
            $stmt->bindParam(":date_borrowed", $dateBorrowed, PDO::PARAM_STR);
            $stmt->bindParam(":date_return", $dateReturn, PDO::PARAM_STR);

            $stmt->execute();

            echo "
                <script>
                    alert('Borrowed Book Added Successfully!');
                    window.location.href = 'http://localhost/book-borrower-system/book-borrowed.php';
                </script>
            ";
        } catch (PDOException $e) {
            echo "Error:" . $e->getMessage();
        }

    } else {
        echo "
            <script>
                alert('Please fill in all the fields!');
                window.location.href = 'http://localhost/book-borrower-system/book-borrowed.php';
            </script>
        ";
    }
}
?>
