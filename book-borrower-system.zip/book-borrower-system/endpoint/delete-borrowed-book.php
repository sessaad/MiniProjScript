<?php
include("../conn/conn.php");

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['borrowed'])) {
        $borrowedID = $_GET['borrowed'];

        try {
            $stmt = $conn->prepare("DELETE FROM tbl_borrowed_book WHERE tbl_borrowed_book_id = :borrowedID");
            $stmt->bindParam(':borrowedID', $borrowedID);
            $stmt->execute();

            echo "
                <script>
                    alert('Borrowed Book Deleted Successfully!');
                    window.location.href = 'http://localhost/book-borrower-system/book-borrowed.php';
                </script>
            ";
            exit();
        } catch (PDOException $e) {
            echo 'Database Error: ' . $e->getMessage();
        }
    } else {
        echo "
            <script>
                alert('Failed to Delete Borrowed Book!');
                window.location.href = 'http://localhost/book-borrower-system/book-borrowed.php';
            </script>
        ";
    }
}
?>
