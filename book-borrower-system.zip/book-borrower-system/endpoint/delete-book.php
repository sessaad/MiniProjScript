<?php
include("../conn/conn.php");

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['book'])) {
        $bookID = $_GET['book'];

        try {
            $stmt = $conn->prepare("DELETE FROM tbl_book_list WHERE tbl_book_list_id = :bookID");
            $stmt->bindParam(':bookID', $bookID);
            $stmt->execute();

            echo "
                <script>
                    alert('Book Deleted Successfully!');
                    window.location.href = 'http://localhost/book-borrower-system/book-list.php';
                </script>
            ";
            exit();
        } catch (PDOException $e) {
            echo 'Database Error: ' . $e->getMessage();
        }
    } else {
        echo "
            <script>
                alert('Failed to Delete Book!');
                window.location.href = 'http://localhost/book-borrower-system/book-list.php';
            </script>
        ";
    }
}
?>
