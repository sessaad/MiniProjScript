<?php
include("../conn/conn.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['book_title'], $_POST['book_author'])) {
        $bookID = $_POST['tbl_book_list_id'];
        $bookTitle = $_POST['book_title'];
        $bookAuthor = $_POST['book_author'];

        try {
            $stmt = $conn->prepare("UPDATE tbl_book_list SET 
            book_title = :book_title, 
            book_author = :book_author  
            WHERE tbl_book_list_id = :tbl_book_list_id");

            $stmt->bindParam("tbl_book_list_id", $bookID, PDO::PARAM_INT);
            $stmt->bindParam("book_title", $bookTitle, PDO::PARAM_STR);
            $stmt->bindParam("book_author", $bookAuthor, PDO::PARAM_STR);

            $stmt->execute();

            echo "
                <script>
                    alert('Book Updated Successfully!');
                    window.location.href = 'http://localhost/book-borrower-system/book-list.php';
                </script>
            ";
        } catch (PDOException $e) {
            echo "Error:". $e->getMessage();
         }

    } else {
        echo "
            <script>
                alert('Please fill in both title and author fields!');
                window.location.href = 'http://localhost/book-borrower-system/book-list.php';
            </script>
        ";
    }
}

?>