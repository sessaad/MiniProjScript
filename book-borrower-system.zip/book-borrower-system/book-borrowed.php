<?php 
include ('./partials/header.php');
include ('./partials/modal.php');
?>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand ml-3" href="">Book Borrower System</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="http://localhost/book-borrower-system/">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="http://localhost/book-borrower-system/book-list.php">List of Books</a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="http://localhost/book-borrower-system/book-borrowed.php">Borrowed</a>
            </li>
            </ul>
        </div>
    </nav>

    <div class="main">
        <div class="book-list-container">
        <div class="container-header row mb-3">
                <div class="col">
                    <h3>List of Borrowed Books</h3>
                </div>
                <div class="col">
                    <button type="button" class="btn btn-secondary" id="addBook" data-toggle="modal" data-target="#addBorrowedBookModal">Add Borrowed Book</button>
                </div>
            </div>
            <table class="table table-sm" id="borrowedTable">
                <thead>
                    <tr>
                    <th scope="col">Borrowed ID</th>
                    <th scope="col">Book ID</th>
                    <th scope="col">Book Title</th>
                    <th scope="col">Borrower's Name</th>
                    <th scope="col">Borrower's Contact</th>
                    <th scope="col">Date Borrowed</th>
                    <th scope="col">Date Return</th>
                    <th scope="col" style="width: 60px;">Action</th>
                    </tr>
                </thead>
                <tbody>

                    <?php 
                        include ('./conn/conn.php');

                        $stmt = $conn->prepare("SELECT * FROM tbl_borrowed_book LEFT JOIN tbl_book_list ON tbl_borrowed_book.tbl_book_list_id = tbl_book_list.tbl_book_list_id");
                        $stmt->execute ();

                        $result = $stmt->fetchAll();

                        foreach ($result as $row) {
                            $borrowedID = $row['tbl_borrowed_book_id'];
                            $bookID = $row['tbl_book_list_id'];
                            $bookName = $row['book_title'];
                            $borrowerName = $row['borrower_name'];
                            $borrowerContact = $row['borrower_contact'];
                            $dateBorrowed = $row['date_borrowed'];
                            $dateReturn = $row['date_return'];
                            ?> 
                            
                            <tr>
                                <th id="borrowedID-<?= $borrowedID ?>"><?= $borrowedID ?></th>
                                <td id="bookID-<?= $borrowedID ?>"><?= $bookID ?></td>
                                <td id="bookName-<?= $borrowedID ?>"><?= $bookName ?></td>
                                <td id="borrowerName-<?= $borrowedID ?>"><?= $borrowerName ?></td>
                                <td id="borrowerContact-<?= $borrowedID ?>"><?= $borrowerContact ?></td>
                                <td id="dateBorrowed-<?= $borrowedID ?>"><?= $dateBorrowed ?></td>
                                <td id="dateReturn-<?= $borrowedID ?>"><?= $dateReturn ?></td>
                                <td>
                                    <button class="btn btn-secondary" type="button" onclick="updateBorrowedBook(<?= $borrowedID ?>)"><i class="fa-solid fa-pencil"></i></button>
                                    <button class="btn btn-danger" type="button" onclick="deleteBorrowedBook(<?= $borrowedID ?>)"><i class="fa-solid fa-trash"></i></button>
                                </td>
                            </tr>
                            <?php
                        }
                    ?>

                </tbody>
            </table>
        </div>
    </div>
    


<?php include ('./partials/footer.php') ?>
